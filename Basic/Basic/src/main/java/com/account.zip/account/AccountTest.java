package com.account;

import java.lang.reflect.Constructor;

public class AccountTest {
    public static void main(String[] args) throws Exception {

        int mode = 1;
        IAccount bank;

        // 객체 생성
        if  ( mode == 0 ) bank = new WRAccount();
        else bank = new KBAccount();

        // 비지니스 로직
        bank.deposit(10000);
        bank.withdraw(5000);

        ((KBAccount)bank).print();

        System.out.println(bank.getBalance());

    }
}
